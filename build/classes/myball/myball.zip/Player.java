
package myball;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JPanel;


class Player extends JPanel
{
    int x_pos =250;
    int y_pos = 500;
    int radius =20;
    public Player()
    {
       
        setOpaque(false);
        setBackground(Color.BLACK);
    }
    public void painting()
    {
         repaint();
    }
    @Override
    public void paint(Graphics G)
    {
        super.paintComponent(G);
        G.setColor(Color.pink);
        G.fillOval(x_pos - radius, y_pos - radius, 2 * radius, 2 * radius);

    }
    public void moveleft()
    {
        x_pos=x_pos-10;
        repaint();
    }
    public void moveright()
    {
        x_pos=x_pos+10;
        repaint();
    }


}

