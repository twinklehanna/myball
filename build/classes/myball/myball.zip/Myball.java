
package myball;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.*;


class Enemy extends JPanel
{
    public Enemy()
    {
        setOpaque(false);
        repaint();
    }
    @Override
    public void paint(Graphics G)
    {
        G.setColor(Color.RED);
        G.fillRect(250,300,250,20);
    }
}
class Enemytwo extends JPanel
{
    public Enemytwo()
    {
        setOpaque(false);
        repaint();
    }
    @Override
    public void paint(Graphics G)
    {
        G.setColor(Color.ORANGE);
        G.fillRect(20,100,80,80);
    }
}


public class Myball extends JFrame
{
    private boolean move=false;

    Myball()
    {
        setSize(500,600);
        setVisible(true);
        Container contentPane = getContentPane();
        setFocusable(true);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        /*****************************************************/

        /*****ADD PLAYER*******/
        Player obj=new Player();
        obj.painting();
        contentPane.add(obj);
        contentPane.setFocusable(true);
        obj.setOpaque(false);
        obj.setSize(500,600);
        /**ADD ENEMIES**/
        Enemy en=new Enemy();
        contentPane.add(en);
        en.setSize(500,600);
        
        Enemytwo en2=new Enemytwo();
        contentPane.add(en2);
        en2.setSize(500, 600);
        /**************************************************/

        addKeyListener(new KeyListener(){
            @Override
            public void keyPressed(KeyEvent e)
            {
                int key = e.getKeyCode();
                System.out.println("key = " + key);
                if (key == KeyEvent.VK_LEFT) {
                    obj.moveleft();

                }
                if (key == KeyEvent.VK_RIGHT) {
                    obj.moveright();
                }

            }
            @Override
            public void keyTyped(KeyEvent e) {}
            @Override
            public void keyReleased(KeyEvent e) {      }

        });

        //*****************************************//
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {

                int time=0;
                boolean stop=true;
                //infini loop
                while (stop)
                {
                    if (!move)
                    {
                        try {
                            Thread.sleep(10);
                        } catch (InterruptedException e) {
                            //do nothing
                        }
                        continue;
                    }

                    obj.y_pos=obj.y_pos-20;
                    
                    if((500<=obj.y_pos-obj.radius && obj.y_pos-obj.radius<=250) && (280<=obj.x_pos-obj.radius &&  obj.x_pos-obj.radius<=320))
                    {
                        JOptionPane.showMessageDialog(null,"you losed :(");
                        stop=false;
                    }
                    repaint();
                    try
                    {
                        Thread.sleep(1000);
                    }
                    catch (InterruptedException ex)
                    {
                        //do nothing
                    }
                    time++;
                    if(time==21)
                    {
                        stop=false;
                    }
                }
            }
        });

        //make jbutton
        JPanel jPanel = new JPanel();
        contentPane.add(jPanel,BorderLayout.SOUTH);
        jPanel.setBackground(Color.BLUE);
        JButton b=new JButton("start");
        b.setFocusable(false);
        b.setSize(50,50);
        jPanel.add(b);
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
                //t.start();
                move=!move;
                b.setText(move ? "stop" : "start");
            }
        } );



        t.start();
    }



    public static void main(String[] args)
    {
        new Myball();


    }



}
